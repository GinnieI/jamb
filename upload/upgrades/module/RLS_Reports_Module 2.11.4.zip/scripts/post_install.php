<?php
if (! defined('sugarEntry') || ! sugarEntry)
	die('Not A Valid Entry Point');

//redirect to license validation page - CHANGE NAME BELOE - To your module name
//header('Location: index.php?module=SampleLicenseAddon&action=license');

function post_install() {
        createSendReportsJob();
		require_once('modules/Configurator/Configurator.php');
		$configurator = new Configurator();
		if(!in_array("rls_Dashboards", $configurator->config['addAjaxBannedModules'])){
			$configurator->config['addAjaxBannedModules'][] = 'rls_Dashboards';
		}
		if(!in_array("rls_Reports", $configurator->config['addAjaxBannedModules'])){
			$configurator->config['addAjaxBannedModules'][] = 'rls_Reports';
		}
        if(!in_array("RLS_Scheduling_Reports", $configurator->config['addAjaxBannedModules'])){
            $configurator->config['addAjaxBannedModules'][] = 'RLS_Scheduling_Reports';
        }
		$configurator->handleOverride();

    global $db;

    if (!$db->tableExists('so_users')) {

        $fieldDefs = array(
            'id' => array (
                'name' => 'id',
                'vname' => 'LBL_ID',
                'type' => 'id',
                'required' => true,
                'reportable' => true,
            ),
            'deleted' => array (
                'name' => 'deleted',
                'vname' => 'LBL_DELETED',
                'type' => 'bool',
                'default' => '0',
                'reportable' => false,
                'comment' => 'Record deletion indicator',
            ),
            'shortname' => array (
                'name' => 'shortname',
                'vname' => 'LBL_SHORTNAME',
                'type' => 'varchar',
                'len' => 255,
            ),
            'user_id' => array (
                'name' => 'user_id',
                'rname' => 'user_name',
                'module' => 'Users',
                'id_name' => 'user_id',
                'vname' => 'LBL_USER_ID',
                'type' => 'relate',
                'isnull' => 'false',
                'dbType' => 'id',
                'reportable' => true,
                'massupdate' => false,
            ),
        );

        $indices = array(
            'id' => array (
                'name' => 'so_userspk',
                'type' => 'primary',
                'fields' => array (
                    0 => 'id',
                ),
            ),
            'shortname' => array (
                'name' => 'shortname',
                'type' => 'index',
                'fields' => array (
                    0 => 'shortname',
                ),
            ),
        );
        $db->createTableParams('so_users',$fieldDefs,$indices);
    }

}

function createSendReportsJob(){
    global $db, $current_user;
    $userid = $current_user->id;
    $sql = "INSERT INTO schedulers
                        (id, deleted, date_entered, date_modified, created_by, modified_user_id, name, job, date_time_start, date_time_end, job_interval, time_from, time_to, last_run, status, catch_up)
                        VALUES ('1d378ab8-378c-0ae3-d06a-557054caacb1', 0, '2015-06-03 12:12:22', '2015-06-04 13:01:32', '" . $userid . "', '" . $userid . "', 'SendReports', 'function::SendReports_Job', '2005-01-01 13:15:00', NULL, '*/1::*::*::*::*', NULL, NULL, '2015-06-03 13:59:00', 'Inactive', 1)";
    $response = $db->query($sql);
    if ($db->checkError()) {
        print_r("<br>MySQL error ".$db->getDatabase()->errno.": ".$db->getDatabase()->error);
    }
}
