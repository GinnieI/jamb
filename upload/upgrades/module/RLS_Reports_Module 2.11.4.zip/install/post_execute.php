<?php

    require_once('install/install_utils.php');
    $GLOBALS['tabStructure']['LBL_TABGROUP_REPORTS'] = array(
        'label' => 'LBL_TABGROUP_REPORTS',
        'modules' => array (
            0 => 'Home',
            1 => 'rls_Reports',
            2 => 'rls_Dashboards',
            3 => 'RLS_Scheduling_Reports',
        ),
    );
    $newFile = create_custom_directory('include/tabConfig.php');
    write_array_to_file("GLOBALS['tabStructure']", $GLOBALS['tabStructure'], $newFile);

  ?>
<script type="text/javascript">
  if (confirm("Add sample reports?")) {
    	window.location = 'index.php?module=RLS_Scheduling_Reports&action=addSampleRecords';
  } else {
      window.location = 'index.php?module=rls_Reports&action=license';    
  }
</script>
