<?php

$mod_strings['LBL_TOTAL'] = 'Total';