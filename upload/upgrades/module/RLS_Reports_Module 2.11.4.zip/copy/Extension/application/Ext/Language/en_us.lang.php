<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$app_strings['LBL_TABGROUP_REPORTS']='Reports';
$app_strings['LBL_CREATE_APPS_BUTTON_LABEL'] = 'Create Applications';