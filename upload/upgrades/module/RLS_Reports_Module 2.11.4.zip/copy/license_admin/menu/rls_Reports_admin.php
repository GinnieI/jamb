<?php

$admin_option_defs=array();
$admin_option_defs['Administration']['rls_Reports_info']= array('helpInline','LBL_REPORTLICENSEADDON_LICENSE_TITLE','LBL_REPORTLICENSEADDON_LICENSE','./index.php?module=rls_Reports&action=license');

$admin_group_header[]= array('LBL_REPORTLICENSEADDON','',false,$admin_option_defs, '');

