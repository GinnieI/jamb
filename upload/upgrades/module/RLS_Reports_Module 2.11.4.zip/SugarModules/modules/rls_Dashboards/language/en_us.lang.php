<?php

$mod_strings = array (
    'LBL_ARE_YOU_SURE' => 'Are you sure?',
);

