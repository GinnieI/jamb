﻿<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$license_strings = array (
'LBL_STEPS_TO_LOCATE_KEY_TITLE' => 'Щоб знайти ключ',
'LBL_STEPS_TO_LOCATE_KEY' => '1. Введіть логін і пароль, щоб <a href="https://www.sugaroutfitters.com" target="_blank">SugarOutfitters</a><br/>2. До Account->Purchases</br>3. Знайдіть ключ на покупку цього доповнення<br/>4. Вставити у вікні License Key нижче<br/>5. натисніть на "Validate"',
'LBL_LICENSE_KEY' => 'ліцензійний ключ',
'LBL_CURRENT_USERS' => 'Поточний Граф Користувач',
'LBL_LICENSED_USERS' => 'Ліцензія Граф Користувач',
'LBL_VALIDATE_LABEL' => 'стверджувати',
'LBL_VALIDATED_LABEL' => 'затверджені',
'LBL_MESSAGE_ERROR' => 'rls_Reports вiдсутнiй лiцензiйний ключ',
);
