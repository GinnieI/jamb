<?php
// created: 2015-06-16 11:43:23
$dictionary["Contact"]["fields"]["rls_scheduling_reports_contacts"] = array (
  'name' => 'rls_scheduling_reports_contacts',
  'type' => 'link',
  'relationship' => 'rls_scheduling_reports_contacts',
  'source' => 'non-db',
  'module' => 'RLS_Scheduling_Reports',
  'bean_name' => 'RLS_Scheduling_Reports',
  'vname' => 'LBL_RLS_SCHEDULING_REPORTS_CONTACTS_FROM_RLS_SCHEDULING_REPORTS_TITLE',
);
