<?php
// created: 2015-06-16 11:39:51
$dictionary["RLS_Scheduling_Reports"]["fields"]["rls_scheduling_reports_users"] = array (
  'name' => 'rls_scheduling_reports_users',
  'type' => 'link',
  'relationship' => 'rls_scheduling_reports_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_RLS_SCHEDULING_REPORTS_USERS_FROM_USERS_TITLE',
);
